const path = require('path');
const cookieParser = require("cookie-parser");
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const session = require('express-session');

const MongoDBStore = require('connect-mongodb-session')(session);

const port = 2025;
const app = express();
const Routers = require('./Routes/routes')

app.set('view engine', 'ejs');
app.set('views', 'views');

app.use(cookieParser());

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(Routers);

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "http://localhost:3001");
  res.setHeader("Access-Control-Allow-Method", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Credentials", true)
  next();
})

const MONGODB_URI =
  'mongodb://localhost:27017/reactjsDB';
const store = new MongoDBStore({
  uri: MONGODB_URI,
  collection: 'sessions'
});
mongoose
  .connect(MONGODB_URI)
  .then(result => {
    console.log("Mongodb Connected")
  })
  .catch(err => {
    console.log(err);
  });

app.listen(port, () => {
  console.log(`App listening on port http://localhost:${port}`)
})
