
const Register = require('../Models/register');

exports.postLogin = async (req, res, next) => {
  const {email , password} = req.body;
  try {
    const user = await Register.findOne({ email, password })
    if (!user) {
      res.status(401).json({
        message: "Login not successful",
        error: "User not found",
      })
    } else {
      res.status(200).json({
        message: "Login successful",
        user,
      })
    }
  } catch (error) {
    res.status(400).json({
      message: "An error occurred",
      error: error.message,
    })
  }
}

exports.getRegister = (req, res) => {
  res.render('register')
}

exports.getLogin = (req, res) => {
  res.render('login')
}



exports.postRegister = async (req, res, next) => {
  const { firstname, lastname, email, phoneno, password, ConfirmPassword, dob, gender,
    country, state, city, address, qualification, programingskill
  } = req.body;
  console.log("hii body of data", req.body)
  try {
    await Register.create({
      firstname,
      lastname,
      email,
      phoneno,
      password,
      ConfirmPassword,
      dob,
      gender,
      country,
      state,
      city,
      address,
      qualification,
      programingskill,
      // profile
    }).then(user =>
      res.status(200).json({
        message: "User successfully created",
        user,
      })
    )
    console.log(user)
  } catch (err) {
    res.status(401).json({
      message: "User not successful created",
      err: err.mesage,
    })
  }
};
