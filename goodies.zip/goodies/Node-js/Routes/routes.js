const router = require('express').Router();
const controller = require('../Controller/controller');


router.post('/login',controller.postLogin)

router.get('/register', controller.getRegister);

router.get('/login', controller.getLogin);

router.post('/register', controller.postRegister);

module.exports = router;