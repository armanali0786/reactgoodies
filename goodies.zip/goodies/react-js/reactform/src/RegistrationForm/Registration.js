import React, { useState } from "react";
import './Registration.css'
import { useNavigate } from "react-router-dom"

const initialValues = {
    name: "",
    email: "",
    password: "",
    ConfirmPassword: "",
};

const Registration = () => {

    const [firstname, setFirstname] = useState('');
    const [lastname, setLastname] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [cpass, setCpass] = useState('');
    const [phoneno, setphoneno] = useState('');
    const [dob, setDob] = useState('');
    const [gender, setGender] = useState('');
    const [country, setCountry] = useState('');
    const [state, setState] = useState('');
    const [city, setCity] = useState('');
    const [address, setAddress] = useState('');
    const [qualification, setQualification] = useState('');
    const [programingskill, setProgramingskill] = useState('');
    // const [profile, setProfile] = useState('');

    const [firstnameerror, setFirstNameError] = useState('');
    const [lastnameerror, setLastNameError] = useState('');
    const [emailerror, setEmailError] = useState('');
    const [passerror, setPassError] = useState('');
    const [cpasserror, setCpassError] = useState('');
    const [phonenoerror, setphonenoError] = useState('');
    const [doberror, setdobError] = useState('');
    const [gendererror, setgenderError] = useState('');
    const [countryerror, setcountryError] = useState('');
    const [stateerror, setstateError] = useState('');
    const [cityerror, setcityError] = useState('');
    const [addresserror, setaddressError] = useState('');
    const [qualificationerror, setqualificationError] = useState('');
    const [programingskillerror, setprogramingskillError] = useState('');
    // const [profileerror, setprofileError] = useState('');

    const [error, setError] = useState('');

    const navigate = useNavigate()

    const handleSubmit = async (e) => {
        e.preventDefault();
        if ((firstnameerror || lastnameerror || emailerror || passerror || cpasserror ||
            phonenoerror || doberror || gendererror || countryerror || stateerror || cityerror
            || addresserror || qualificationerror || programingskillerror)
            == "") {
            setError("Field can't be empty")
        }
        else {
            setError('')
            // navigate("/login")
        }

        let items = {
            "firstname": firstname,
            "lastname": lastname,
            "email": email,
            "phoneno": phoneno,
            "password": password,
            "ConfirmPassword": cpass,
            "dob": dob,
            "gender": gender,
            "country": country,
            "state": state,
            "city": city,
            "address": address,
            "qualification": qualification,
            "programingskill": programingskill,
            //   profile

        };
        const response = await fetch(
            "http://localhost:2025/register",
            {
                method: "POST",
                headers: {
                    // Accept: "application/json",
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    firstname,
                    lastname,
                    email,
                    phoneno,
                    password,
                    cpass,
                    dob,
                    gender,
                    country,
                    state,
                    city,
                    address,
                    qualification,
                    programingskill,
                }),
                //  body: JSON.stringify(items),
            });
        const data = await response.json();
        const messege = await data.message
        console.log(items)
        if (response.status == 200) {
            navigate('/login')
        }

    };

    const firstnamehandleChange = (e) => {
        if (e.target.value == "") {
            console.log(e.target.value);
            setFirstNameError("name can't be empty")
        }
        else {
            setFirstname(e.target.value)
            setError('')
            setFirstNameError("")
        }
    }
    const lastnamehandleChange = (e) => {
        if (e.target.value == "") {
            console.log(e.target.value);
            setLastNameError("Last name can't be empty")
        }
        else {
            setLastname(e.target.value)
            setError('')
            setLastNameError("")
        }
    }


    const emailhandleChange = (e) => {
        if (e.target.value === "") {
            setEmailError("Email can't be empty")
        }
        else {
            setEmail(e.target.value)
            setError('')

            setEmailError("")
        }
    }

    const passwordhandleChange = (e) => {
        if (e.target.value === "") {
            setPassError("Password can't be empty")
        }
        else {
            setPassword(e.target.value)
            setError('')
            setPassError("")
        }
    }

    const Cpasshandlechange = (e) => {
        if (e.target.value === "") {
            setCpassError("Confirm Password can't be empty")
        }
        else {
            setCpass(e.target.value)
            setError('')
            setCpassError("")
        }
    }
    const phonenohandlechange = (e) => {
        if (e.target.value === "") {
            setphonenoError("Phone no can't be empty")
        }
        else {
            setphoneno(e.target.value)
            setError('')
            setphonenoError("")
        }
    }

    const dobHandlechange = (e) => {
        if (e.target.value === "") {
            setdobError("Date of Birth can't be empty")
        }
        else {
            setDob(e.target.value)
            setError('')
            setdobError("")
        }
    }
    const genderHandlechange = (e) => {
        if (e.target.value === "") {
            setgenderError("Gender Password can't be empty")
        }
        else {
            setGender(e.target.value)
            setError('')
            setgenderError("")
        }
    }
    const countryrHandlechange = (e) => {
        if (e.target.value === "") {
            setcountryError("Country Password can't be empty")
        }
        else {
            setCountry(e.target.value)
            setError('')
            setcountryError("")
        }
    }
    const stateHandlechange = (e) => {
        if (e.target.value === "") {
            setstateError(" State can't be empty")
        }
        else {
            setState(e.target.value)
            setError('')
            setstateError("")
        }
    }
    const cityHandlechange = (e) => {
        if (e.target.value === "") {
            setcityError("City Password can't be empty")
        }
        else {
            setCity(e.target.value)
            setError('')
            setcityError("")
        }
    }
    const addressHandleChange = (e) => {
        if (e.target.value === "") {
            setaddressError("Address  can't be empty")
        }
        else {
            setAddress(e.target.value)
            setError('')
            setaddressError("")
        }

    }
    const programmingHandlechange = (e) => {
        if (e.target.value === "") {
            setprogramingskillError(" Programing Skill can't be empty")
        }
        else {
            setProgramingskill(e.target.value)
            setError('')
            setprogramingskillError("")
        }
    }
    const qualificationHandleChange = (e) => {
        if (e.target.value === "") {
            setprogramingskillError("  Qualification can't be empty")
        }
        else {
            setProgramingskill(e.target.value)
            setError('')
            setprogramingskillError("")
        }
    }
    // const profileHandleChange = (e) => {
    //     if (e.target.value === "") {
    //         setprofileError("Confirm Password can't be empty")
    //     }
    //     else {
    //         setProfile(e.target.value)
    //         setError('')
    //         setprofileError("")
    //     }
    // }
    const [passwordType, setPasswordType] = useState("password");
    const [passwordInput, setPasswordInput] = useState("");
    const handlePasswordChange = (evnt) => {
        setPasswordInput(evnt.target.value);
    }
    const togglePassword = () => {
        if (passwordType === "password") {
            setPasswordType("text")
            return;
        }
        setPasswordType("password")
    }

    return (
        <>
            <div className="container">
                <div className="modal">
                    <div className="modal-container">
                        <div className="modal-left">
                            <h1 className="modal-title">Welcome!</h1>
                            <p className="modal-desc">
                                To Registration Page
                            </p>
                            <form onSubmit={handleSubmit}>
                                <div className="input-block">
                                    <label htmlFor="firstname" className="input-label">
                                        First Name
                                    </label>
                                    <input
                                        type="text"
                                        autoComplete="off"
                                        name="firstname"
                                        id="firstname"
                                        placeholder="FirstName"
                                        value={firstname}
                                        onChange={firstnamehandleChange}
                                    />
                                    {firstname ? <small>{firstnameerror}</small> : null}
                                </div>
                                <div className="input-block">
                                    <label htmlFor="lastname" className="input-label">
                                        Last Name
                                    </label>
                                    <input
                                        type="text"
                                        autoComplete="off"
                                        name="lastname"
                                        id="lastname"
                                        placeholder="Name"
                                        value={lastname}
                                        onChange={lastnamehandleChange}
                                    />
                                    {lastname ? <small>{lastnameerror}</small> : null}
                                </div>
                                <div className="input-block">
                                    <label htmlFor="email" className="input-label">
                                        Email
                                    </label>
                                    <input
                                        type="email"
                                        autoComplete="off"
                                        name="email"
                                        id="email"
                                        placeholder="Email"
                                        value={email}
                                        onChange={emailhandleChange}
                                    />
                                    {email ? <small>{emailerror}</small> : null}

                                </div>
                                <div className="input-block">
                                    <label htmlFor="password" className="input-label">
                                        Password
                                    </label>
                                    <input
                                        type={passwordType}
                                        autoComplete="off"
                                        name="password"
                                        id="password"
                                        placeholder="Password"
                                        value={password}
                                        onChange={passwordhandleChange}
                                    />
                                    <div>
                                    <label htmlFor="password" className="input-label">
                                        Show
                                    </label>
                                    
                                    <input type="checkbox"  onClick={togglePassword}>
                                    </input>
                                    </div>
                                    {password ? <small>{passerror}</small> : null}

                                </div>

                                <div className="input-block">
                                    <label htmlFor="ConfirmPassword" className="input-label">
                                        Confirm Password
                                    </label>
                                    <input
                                        type="password"
                                        autoComplete="off"
                                        name="ConfirmPassword"
                                        id="ConfirmPassword"
                                        placeholder="Confirm Password"
                                        value={cpass}
                                        onChange={Cpasshandlechange}
                                    />
                                     <div>
                                    <label htmlFor="password" className="input-label">
                                        Show
                                    </label>
                                    
                                    <input type="checkbox"  onClick={togglePassword}>
                                    </input>
                                    </div>
                                </div>
                                <div className="input-block">
                                    <label htmlFor="Phoneno" className="input-label">
                                        PhoneNumber
                                    </label>
                                    <input
                                        type="number"
                                        autoComplete="off"
                                        name="phoneno"
                                        id="phoneno"
                                        value={phoneno}
                                        onChange={phonenohandlechange}

                                    />
                                    {cpass ? <small>{cpasserror}</small> : null}

                                </div>
                                <div className="input-block">
                                    <label htmlFor="date" className="input-label">
                                        Date
                                    </label>
                                    <input
                                        type="date"
                                        autoComplete="off"
                                        name="dob"
                                        id="dob"
                                        placeholder="Date"
                                        value={dob}
                                        onChange={dobHandlechange}
                                    />

                                </div>

                                <div className="input-block">
                                    <label htmlFor="gender" className="input-label">
                                        Gender
                                    </label>
                                    <input
                                        type="radio"
                                        autoComplete="off"
                                        value="Male"
                                        name="gender"
                                        // value ={}
                                        onChange={genderHandlechange}
                                    /> Male
                                    <input
                                        type="radio"
                                        autoComplete="off"
                                        value="Female"
                                        name="gender"
                                        onChange={genderHandlechange}
                                    /> Female

                                    <input
                                        type="radio"
                                        autoComplete="off"
                                        value="other"
                                        name="gender"
                                        onChange={genderHandlechange}
                                    /> other
                                </div>

                                <div className="input-block">
                                    <label htmlFor="country" className="input-label">
                                        Country
                                    </label>
                                    <select name="country" id="country" onChange={countryrHandlechange}>

                                        <option value="India">India</option>
                                        <option value="Nepal">Nepal</option>
                                        <option value="Saudi">Saudi</option>
                                        value ={country}
                                    </select>
                                </div>

                                <div className="input-block">
                                    <label htmlFor="state" className="input-label">
                                        State
                                    </label>
                                    <select name="state" id="state" onChange={stateHandlechange}>
                                        <option value="bihar">Bihar</option>
                                        <option value="delhi">Delhi</option>
                                        <option value="gujarat">Gujarat</option>
                                        value ={state}
                                    </select>

                                </div>


                                <div className="input-block">
                                    <label htmlFor="city" className="input-label">
                                        City
                                    </label>
                                    <select name="city" id="city" onChange={cityHandlechange}>
                                        <option value="pune">Gopalganj</option>
                                        <option value="chennai">Siwan</option>
                                        <option value="lolkata">Patna</option>
                                        value={city}
                                    </select>

                                </div>

                                <div className="input-block">
                                    <label htmlFor="address" className="input-label">
                                        Address
                                    </label>
                                    <input
                                        type="textarea"
                                        autoComplete="off"
                                        name="address"
                                        id="address"
                                        value={address}
                                        onChange={addressHandleChange}
                                    />

                                </div>
                                <div className="input-block">
                                    <label htmlFor="qualification" className="input-label">
                                        Qualification
                                    </label>
                                    <div>
                                        <input
                                            type="checkbox"
                                            autoComplete="off"
                                            name="btech"
                                            id="btech"
                                            value={qualification}
                                            onChange={qualificationHandleChange}
                                        />
                                        <label for="scales">Btech</label>
                                    </div>

                                    <div>
                                        <input
                                            type="checkbox"
                                            autoComplete="off"
                                            name="mtech"
                                            id="mtech"
                                            value={qualification}
                                            onChange={qualificationHandleChange}
                                        />
                                        <label for="scales">Mtech</label>
                                    </div>
                                </div>

                                <div className="input-block">
                                    <label htmlFor="programingskiil" className="input-label">
                                        programingskiil
                                    </label>
                                    <select name="city" id="city" onChange={programmingHandlechange}>
                                        <option value="nodejs">Nodejs</option>
                                        <option value="reactjs">Reactjs</option>
                                        <option value="javascript">Javascript</option>
                                        value={programingskill}
                                    </select>
                                </div>

                                <div className="modal-buttons">
                                    <button className="input-button" type="submit">
                                        Registration
                                    </button>
                                </div>
                                {error ? <small>{error}</small> : null}
                            </form>
                            <p className="sign-up">
                                Already have an account? <a href="/login">Sign In now</a>
                            </p>
                        </div>
                        <div className="modal-right">
                            <img
                                src="https://design4users.com/wp-content/uploads/2019/11/light-dark-UI-design-tips-tubik-blog.jpg"
                                alt=""
                            />
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Registration;
