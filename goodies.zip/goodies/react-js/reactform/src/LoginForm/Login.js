import React, { useState } from "react";
import './Login.css'
import { useNavigate } from "react-router-dom"

const initialValues = {
    email: "",
    password: ""
};


const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [emailerror, setEmailError] = useState('');
    const [passerror, setPassError] = useState('');
    const [error, setError] = useState('');

    const navigate = useNavigate()

    const handleSubmit = async (e) => {
        e.preventDefault();
        if ((emailerror || passerror) == "") {
            setError("Field can't be empty")
        }
        else {
            setError('')
            navigate("/register")
        }
        let items = {
            'email': email,
            'password': password,
          };
          const response = await fetch(
            "http://localhost:2025/login",
            {
              method: "POST",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                  email:email,
                  password:password,            
                }),
            });
          const data = await response.json();
            console.log(data)
        };


    const emailhandleChange = (e) => {
        if (e.target.value === "") {
            setEmailError("Email can't be empty")
        }
        else {
            setEmail(e.target.value)
            setError('')
            setEmailError("")
        }
    }

    const passwordhandleChange = (e) => {
        if (e.target.value === "") {
            setPassError("Password can't be empty")
        }
        else {
            setPassword(e.target.value)
            setError('')
            setPassError("")
        }
    }

    return (
        <>
            <div className="container">
                <div className="modal">
                    <div className="modal-container">
                        <div className="modal-left">
                            <h1 className="modal-title">Welcome to Login Page!</h1>
                            <p className="modal-desc">
                            </p>
                            <form onSubmit={handleSubmit}>
                                <div className="input-block">
                                    <label htmlFor="email" className="input-label">
                                        Email
                                    </label>
                                    <input
                                        type="email"
                                        autoComplete="off"
                                        name="email"
                                        id="email"
                                        placeholder="Email"
                                        onChange={emailhandleChange}
                                    />
                                    {email ? <small>{emailerror}</small> : null}

                                </div>
                                <div className="input-block">
                                    <label htmlFor="password" className="input-label">
                                        Password
                                    </label>
                                    <input
                                        type="password"
                                        autoComplete="off"
                                        name="password"
                                        id="password"
                                        placeholder="Password"
                                        onChange={passwordhandleChange}
                                    />
                                    {password ? <small>{passerror}</small> : null}

                                </div>
                                <div className="modal-buttons">
                                    <button className="input-button" type="submit">
                                        Login
                                    </button>
                                </div>
                                {error ? <small>{error}</small> : null}
                            </form>
                            <p className="sign-up">
                                If You haven't an account? <a href="/register">Sign Up now</a>
                            </p>
                        </div>
                        <div className="modal-right">
                            <img
                                src="https://images.unsplash.com/photo-1512486130939-2c4f79935e4f?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=dfd2ec5a01006fd8c4d7592a381d3776&auto=format&fit=crop&w=1000&q=80"
                                alt=""
                            />
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Login;
