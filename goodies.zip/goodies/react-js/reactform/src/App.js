import './App.css';
import { BrowserRouter , Routes , Route} from "react-router-dom"
import Registration from './RegistrationForm/Registration';
import Login from './LoginForm/Login';

function App() {
  return (
    <BrowserRouter>
     <Routes>
      <Route path='/login' index element={<Login/>}/>
      <Route path='/register' element={<Registration/>}/>
     </Routes>
    </BrowserRouter>
  );
}

export default App;
